/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IT2344Assignment02;

/**
 *
 * @author jbcanala
 * DO NOT CHANGE ANYTHING HERE
 */
public abstract class Student {
    protected double wpa;

    public Student(double wpa) {
        this.wpa = wpa;
    }

    public abstract String status();
    
}
